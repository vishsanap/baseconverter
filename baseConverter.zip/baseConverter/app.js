/**
 * Created by dell on 6/21/2017.
 */
var myApp = angular.module('myApp',[]);
myApp.controller('myController',['$scope','$filter',function($scope,filter)
{
    $scope.decimal = "";
    $scope.binary = "";
    $scope.ocatal = "";
    $scope.hexa = "";

    $scope.$watch('decimal',function (newValue, oldValue) {

        if(newValue !="") {
            $scope.binary = parseInt(newValue, 10).toString(2);
            $scope.octal = parseInt(newValue, 10).toString(8);
            $scope.hexa = parseInt(newValue, 10).toString(16).toUpperCase();
        } else {

            $scope.binary = "";
            $scope.ocatal = "";
            $scope.hexa = "";

        }

    });

    $scope.$watch('binary',function (newValue, oldValue) {
        if(newValue !="") {
            $scope.decimal = parseInt(newValue, 2).toString(10);
        }
        else {
            $scope.decimal = "";
        }
    });
    $scope.$watch('octal',function (newValue, oldValue) {
        if(newValue !="") {

            $scope.decimal = parseInt(newValue, 8).toString(10);
        }
        else
        {
            $scope.decimal = "";
        }
    });
    $scope.$watch('hexa',function (newValue, oldValue) {
        if(newValue !="") {
            $scope.decimal = parseInt(newValue,16).toString(10);
    }
    else
    {
        $scope.decimal = "";
    }

});




}]);